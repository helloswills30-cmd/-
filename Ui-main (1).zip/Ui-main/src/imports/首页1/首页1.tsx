import svgPaths from "./svg-b9ohtyztwh";
import imgImage from "./44943e41a3a0dbe1d8e9ecece1cf8e06245043cd.png";
import imgImage1 from "./9ba8492527d0d30849b53217280160f66a3a4a7a.png";
import imgImage2 from "./1a83ca08e0a509e8f6d6974525a8e5dea9f400fa.png";

function Container3() {
  return (
    <div className="absolute h-[26.107px] left-0 top-0 w-[334.164px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[26.107px] left-0 not-italic text-[#364153] text-[18.275px] top-[-0.26px] whitespace-nowrap">Hi, 探索匠</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex h-[41.754px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[41.77px] min-w-px not-italic relative text-[#0a0a0a] text-[31.328px]">探索城市的</p>
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[36.549px] left-[130.53px] top-[2.59px] w-[19.351px]" data-name="Text">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[36.549px] left-0 not-italic text-[#0a0a0a] text-[23.496px] top-[-0.78px] whitespace-nowrap">☆</p>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[41.754px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[41.77px] left-0 not-italic text-[#0a0a0a] text-[31.328px] top-[-2.61px] whitespace-nowrap">{`无限可能 `}</p>
      <Text />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.221px] h-[88.73px] items-start left-0 top-[36.55px] w-[334.164px]" data-name="Container">
      <Heading />
      <Heading1 />
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[20.869px] relative shrink-0 w-[88.811px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20.885px] min-w-px not-italic relative text-[#4a5565] text-[15.664px]">📍 专属探索</p>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex h-[20.869px] items-start left-0 top-[146.16px] w-[334.164px]" data-name="Container">
      <Text1 />
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[135.75px] size-[20.885px] top-[13.05px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.8852 20.8852">
        <g id="Icon">
          <path d={svgPaths.p3a44ab00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.74044" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#ff8904] h-[46.992px] left-0 rounded-[35039528px] top-[182.7px] w-[177.524px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[26.107px] left-[75.89px] not-italic text-[18.275px] text-center text-white top-[10.18px] whitespace-nowrap">{`快速开始探索 `}</p>
      <Icon />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute content-stretch flex h-[20.869px] items-start left-0 top-[240.13px] w-[334.164px]" data-name="Paragraph">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20.885px] min-w-px not-italic relative text-[#4a5565] text-[15.664px]">基于你的技能定制无限可能</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[261px] left-0 top-0 w-[355.049px]" data-name="Container">
      <Container3 />
      <Container4 />
      <Container5 />
      <Button />
      <Paragraph />
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[199.95px] left-[104px] top-[147px] w-[400px]" data-name="Container">
      <Container2 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-0 size-[32.545px] top-0" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32.5449 32.5449">
        <g id="Icon">
          <path d={svgPaths.p1201cb80} id="Vector" stroke="var(--stroke-0, #1E2939)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.71207" />
          <path d={svgPaths.pe90d9f0} id="Vector_2" stroke="var(--stroke-0, #1E2939)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.71207" />
        </g>
      </svg>
    </div>
  );
}

function Container7() {
  return <div className="absolute bg-[#fb2c36] left-[27.12px] rounded-[36400784px] size-[10.848px] top-[-5.42px]" data-name="Container" />;
}

function Container6() {
  return (
    <div className="absolute left-[542.41px] size-[32.545px] top-[21.7px]" data-name="Container">
      <Icon1 />
      <Container7 />
    </div>
  );
}

function Container() {
  return (
    <div className="absolute h-[539px] left-[-70px] rounded-bl-[32.545px] rounded-br-[32.545px] top-0 w-[533px]" data-name="Container">
      <Container1 />
      <Container6 />
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[20px] relative shrink-0 w-[28px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0a0a0a] text-[14px] top-[-0.2px] whitespace-nowrap">9:41</p>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M8 13.3333H8.00667" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3978c100} id="Vector_2" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3aa7f280} id="Vector_3" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3129d700} id="Vector_4" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Icon3() {
  return (
    <div className="flex-[1_0_0] h-[16px] min-w-px relative" data-name="Icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <div className="absolute bottom-[29.17%] left-[8.33%] right-1/4 top-[29.17%]" data-name="Vector">
          <div className="absolute inset-[-10%_-6.25%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 8">
              <path d={svgPaths.p3f294f40} id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            </svg>
          </div>
        </div>
        <div className="absolute inset-[45.83%_8.33%_45.83%_91.67%]" data-name="Vector">
          <div className="absolute inset-[-50%_-0.67px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.33333 2.66667">
              <path d="M0.666667 0.666667V2" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[16px] relative shrink-0 w-[36px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative size-full">
        <Icon2 />
        <Icon3 />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex h-[35px] items-center justify-between left-[-1px] pb-[8px] pt-[12px] px-[16px] top-0 w-[396px]" data-name="Container">
      <Container9 />
      <Container10 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[16.966px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.9664 16.9664">
        <g id="Icon">
          <path d={svgPaths.pc655c80} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d={svgPaths.p21330800} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
        </g>
      </svg>
    </div>
  );
}

function TextInput() {
  return (
    <div className="flex-[302.4_0_0] h-[16.966px] min-w-px relative" data-name="Text Input">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[normal] not-italic relative shrink-0 text-[#99a1af] text-[11.876px] whitespace-nowrap">今天想干什么?</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[16.966px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.9664 16.9664">
        <g id="Icon">
          <path d={svgPaths.p227afa00} id="Vector" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d={svgPaths.p49a1c80} id="Vector_2" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d={svgPaths.pb578e80} id="Vector_3" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d={svgPaths.p28275b80} id="Vector_4" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M14.8456 14.8455V14.8527" id="Vector_5" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d={svgPaths.p3f185500} id="Vector_6" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M2.12087 8.48308H2.12815" id="Vector_7" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M8.48325 2.1207H8.49053" id="Vector_8" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M8.48325 11.3107V11.318" id="Vector_9" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M11.3111 8.48308H12.018" id="Vector_10" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M14.8456 8.48308V8.49036" id="Vector_11" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
          <path d="M8.48325 14.8455V14.1386" id="Vector_12" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41386" />
        </g>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[10.18px] h-[38.683px] items-center left-[13px] px-[14.252px] py-[10.859px] rounded-[22771818px] top-[187px] w-[339.327px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f3f4f6] border-[0.679px] border-solid inset-0 pointer-events-none rounded-[22771818px] shadow-[0px_8.483px_12.725px_0px_rgba(0,0,0,0.1),0px_3.393px_5.09px_0px_rgba(0,0,0,0.1)]" />
      <Icon4 />
      <TextInput />
      <Icon5 />
    </div>
  );
}

function Image() {
  return (
    <div className="h-[35px] relative shrink-0 w-[36px]" data-name="Image">
      <div className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[117.07%] left-[-3.58%] max-w-none top-[-0.79%] w-[111.95%]" src={imgImage} />
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="relative shrink-0 size-[48px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[4px] relative size-full">
        <Image />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[52px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold',sans-serif] font-bold leading-[19.5px] left-[26px] not-italic text-[#101828] text-[13px] text-center top-[-0.2px] whitespace-nowrap">情绪探索</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[26px] relative shrink-0 w-[99.063px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[13px] left-[50px] not-italic text-[#6a7282] text-[10px] text-center top-0 w-[100px]">测测今天适合什么消费路线</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[6px] items-center justify-center left-0 pb-[5.588px] pt-[5.575px] px-[8.8px] rounded-[14px] size-[116.662px] top-[251px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f3f4f6] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container13 />
      <Container14 />
      <Container15 />
    </div>
  );
}

function Image1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Image">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage1} />
    </div>
  );
}

function Container16() {
  return (
    <div className="relative shrink-0 size-[48px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[4px] relative size-full">
        <Image1 />
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[52px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_JP:Bold','Noto_Sans_SC:Bold','Noto_Sans_KR:Bold',sans-serif] font-bold leading-[19.5px] left-[26px] not-italic text-[#101828] text-[13px] text-center top-[-0.2px] whitespace-nowrap">省钱挑战</p>
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[26px] relative shrink-0 w-[99.063px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[13px] left-[50px] not-italic text-[#6a7282] text-[10px] text-center top-0 w-[100px]">输入需求，AI帮你砍到极致</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[6px] items-center justify-center left-[124.66px] pb-[5.588px] pt-[5.575px] px-[8.8px] rounded-[14px] size-[116.662px] top-[251px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f3f4f6] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container16 />
      <Container17 />
      <Container18 />
    </div>
  );
}

function Image2() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Image">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage2} />
    </div>
  );
}

function Container19() {
  return (
    <div className="relative shrink-0 size-[48px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[4px] relative size-full">
        <Image2 />
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[19.5px] relative shrink-0 w-[52px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Bold','Noto_Sans_SC:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[19.5px] left-[26px] not-italic text-[#101828] text-[13px] text-center top-[-0.2px] whitespace-nowrap">积分联盟</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[26px] relative shrink-0 w-[99.063px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[13px] left-[50px] not-italic text-[#6a7282] text-[10px] text-center top-0 w-[100px]">跨店攒积分，一分不浪费</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[6px] items-center justify-center left-[249.33px] pb-[5.588px] pt-[5.575px] px-[8.8px] rounded-[14px] size-[116.662px] top-[251px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f3f4f6] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container19 />
      <Container20 />
      <Container21 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[17px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="Icon">
          <path d={svgPaths.pef5200} fill="var(--fill-0, #FFB900)" id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.0625" />
          <g id="Vector_2">
            <path d="M3.54167 14.875H13.4583Z" fill="var(--fill-0, #FFB900)" />
            <path d="M3.54167 14.875H13.4583" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.0625" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Container22() {
  return (
    <div className="bg-white relative rounded-[26843500px] shrink-0 size-[34px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[0.8px] border-black border-solid inset-0 pointer-events-none rounded-[26843500px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[8.5px] py-[0.8px] relative size-full">
        <Icon6 />
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[21px] relative shrink-0 w-[56px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Bold','Noto_Sans_JP:Bold',sans-serif] font-bold leading-[21px] left-0 not-italic text-[#101828] text-[14px] top-[-0.4px] whitespace-nowrap">我的段位</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="bg-[#ffedd4] h-[19px] relative rounded-[4px] shrink-0 w-[52px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[#ff6900] text-[10px] top-[1.8px] whitespace-nowrap">消费韭菜</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[21px] items-center left-0 top-0 w-[258.4px]" data-name="Container">
      <Text2 />
      <Text3 />
    </div>
  );
}

function Container25() {
  return (
    <div className="absolute h-[16.5px] left-0 top-[23px] w-[258.4px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#6a7282] text-[11px] top-[-0.2px] whitespace-nowrap">再省下 ¥50 即可升级 · 精打细算</p>
    </div>
  );
}

function Container27() {
  return <div className="bg-gradient-to-r from-[#ff8904] h-[6px] rounded-[26843500px] shrink-0 to-[#ff6900] w-full" data-name="Container" />;
}

function Container26() {
  return (
    <div className="absolute bg-[#f3f4f6] content-stretch flex flex-col h-[6px] items-start left-0 overflow-clip pr-[167.962px] rounded-[26843500px] top-[45.5px] w-[258.4px]" data-name="Container">
      <Container27 />
    </div>
  );
}

function Container23() {
  return (
    <div className="flex-[258.4_0_0] h-[51.5px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container24 />
        <Container25 />
        <Container26 />
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M6 12L10 8L6 4" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function MyRank() {
  return (
    <div className="absolute bg-white content-stretch flex gap-[12px] h-[77.1px] items-center left-0 px-[16.8px] py-[12.8px] rounded-[14px] top-[400.66px] w-[366px]" data-name="MyRank">
      <div aria-hidden="true" className="absolute border-[#f3f4f6] border-[0.8px] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <Container22 />
      <Container23 />
      <Icon7 />
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute h-[585px] left-[13px] overflow-clip top-[260px] w-[380.046px]" data-name="Container">
      <Container12 />
      <Button1 />
      <Button2 />
      <Button3 />
      <MyRank />
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[21.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.75 21.75">
        <g id="Icon">
          <path d={svgPaths.p5b459c0} id="Vector" stroke="var(--stroke-0, #FF6900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
          <path d={svgPaths.p31fe17b8} id="Vector_2" stroke="var(--stroke-0, #FF6900)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
        </g>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[14.489px] relative shrink-0 w-[21.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[14.5px] not-italic relative shrink-0 text-[#ff6900] text-[10.875px] text-center whitespace-nowrap">首页</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.625px] h-[54.364px] items-center justify-center left-0 py-[7.25px] top-0 w-[79.75px]" data-name="Button">
      <Icon8 />
      <Text4 />
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[21.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.75 21.75">
        <g id="Icon">
          <path d={svgPaths.pd107000} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
          <path d={svgPaths.p10f91400} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[14.489px] relative shrink-0 w-[21.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[14.5px] not-italic relative shrink-0 text-[#99a1af] text-[10.875px] text-center whitespace-nowrap">探索</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.625px] h-[54.364px] items-center justify-center left-[94.25px] py-[7.25px] top-0 w-[79.75px]" data-name="Button">
      <Icon9 />
      <Text5 />
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[21.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.75 21.75">
        <g id="Icon">
          <path d={svgPaths.p20f8aa80} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
          <path d={svgPaths.p32ec2800} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[14.489px] relative shrink-0 w-[21.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[14.5px] not-italic relative shrink-0 text-[#99a1af] text-[10.875px] text-center whitespace-nowrap">发现</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.625px] h-[54.364px] items-center justify-center left-[188.5px] py-[7.25px] top-0 w-[79.75px]" data-name="Button">
      <Icon10 />
      <Text6 />
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[21.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.75 21.75">
        <g id="Icon">
          <path d={svgPaths.p114a4900} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
          <path d={svgPaths.p346b4900} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8125" />
        </g>
      </svg>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[14.489px] relative shrink-0 w-[21.75px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[14.5px] not-italic relative shrink-0 text-[#99a1af] text-[10.875px] text-center whitespace-nowrap">我的</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[3.625px] h-[54.364px] items-center justify-center left-[282.75px] py-[7.25px] top-0 w-[79.75px]" data-name="Button">
      <Icon11 />
      <Text7 />
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[54.364px] relative shrink-0 w-full" data-name="Container">
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[69.589px] items-start left-[-13px] pt-[7.975px] px-[21.75px] top-[788px] w-[406px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-solid border-t-[0.725px] inset-0 pointer-events-none shadow-[0px_9.063px_13.594px_0px_rgba(0,0,0,0.1),0px_3.625px_5.438px_0px_rgba(0,0,0,0.1)]" />
      <Container29 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white relative size-full" data-name="首页1">
      <Container />
      <Container8 />
      <Container11 />
      <Container28 />
    </div>
  );
}